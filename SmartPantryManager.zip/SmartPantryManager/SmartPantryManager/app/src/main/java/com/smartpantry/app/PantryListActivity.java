package com.smartpantry.app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class PantryListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new PantryFragment())
                    .commit();
        }
    }
}
