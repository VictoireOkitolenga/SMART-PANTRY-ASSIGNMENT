package com.smartpantry.app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.smartpantry.app.database.DatabaseHelper;
import com.smartpantry.app.logic.StrictMatcher;
import com.smartpantry.app.models.PantryItem;
import com.smartpantry.app.models.Recipe;
import java.util.List;

/**
 * Main navigation activity coordinating Pantry, Suggestions, and Settings screens.
 */
public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private DatabaseHelper dbHelper;

    private PantryFragment pantryFragment;
    private SuggestionsFragment suggestionsFragment;
    private SettingsFragment settingsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        pantryFragment = new PantryFragment();
        suggestionsFragment = new SuggestionsFragment();
        settingsFragment = new SettingsFragment();

        bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_pantry) {
                loadFragment(pantryFragment);
                return true;
            } else if (itemId == R.id.nav_suggestions) {
                loadFragment(suggestionsFragment);
                return true;
            } else if (itemId == R.id.nav_settings) {
                loadFragment(settingsFragment);
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            loadFragment(pantryFragment);
        }

        updateSuggestionsBadge();
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    public void switchToTab(int navItemId) {
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(navItemId);
        }
    }

    public void updateSuggestionsBadge() {
        if (dbHelper == null || bottomNav == null) return;

        List<Recipe> recipes = dbHelper.getAllRecipes();
        List<PantryItem> pantry = dbHelper.getAllPantryItems();

        int strictCount = 0;
        for (Recipe r : recipes) {
            if (StrictMatcher.evaluate(r, pantry).isStrictMatch()) {
                strictCount++;
            }
        }

        BadgeDrawable badge = bottomNav.getOrCreateBadge(R.id.nav_suggestions);
        badge.setBackgroundColor(getResources().getColor(R.color.primary, getTheme()));
        badge.setBadgeTextColor(getResources().getColor(R.color.white, getTheme()));

        if (strictCount > 0) {
            badge.setVisible(true);
            badge.setNumber(strictCount);
        } else {
            badge.setVisible(false);
        }
    }
}
