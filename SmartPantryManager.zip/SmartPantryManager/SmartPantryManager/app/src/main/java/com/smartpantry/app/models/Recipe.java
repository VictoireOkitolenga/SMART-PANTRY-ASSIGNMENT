package com.smartpantry.app.models;

import java.io.Serializable;
import java.util.List;

public class Recipe implements Serializable {
    private String id;
    private String name;
    private String description;
    private String category;
    private int prepTimeMinutes;
    private int cookTimeMinutes;
    private int servings;
    private String difficulty;
    private List<RecipeIngredient> ingredients;
    private List<String> instructions;

    public Recipe(String id, String name, String description, String category, int prepTimeMinutes, int cookTimeMinutes, int servings, String difficulty, List<RecipeIngredient> ingredients, List<String> instructions) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.prepTimeMinutes = prepTimeMinutes;
        this.cookTimeMinutes = cookTimeMinutes;
        this.servings = servings;
        this.difficulty = difficulty;
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public int getPrepTimeMinutes() { return prepTimeMinutes; }
    public int getCookTimeMinutes() { return cookTimeMinutes; }
    public int getServings() { return servings; }
    public String getDifficulty() { return difficulty; }
    public List<RecipeIngredient> getIngredients() { return ingredients; }
    public List<String> getInstructions() { return instructions; }
}
