package com.smartpantry.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.smartpantry.app.adapters.PantryAdapter;
import com.smartpantry.app.database.DatabaseHelper;
import com.smartpantry.app.models.PantryItem;
import java.util.ArrayList;
import java.util.List;

public class PantryFragment extends Fragment implements PantryAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private PantryAdapter adapter;
    private List<PantryItem> pantryList = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private TextView tvEmpty, tvSummary, btnFindRecipesLink;
    private EditText etSearch;
    private FloatingActionButton fabAdd;

    private TextView chipAll, chipProduce, chipDairy, chipMeat, chipPantry, chipSpices;
    private String selectedCategory = "All";
    private String currentSearchQuery = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_pantry_list, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        recyclerView = view.findViewById(R.id.recycler_pantry);
        tvEmpty = view.findViewById(R.id.tv_empty_pantry);
        tvSummary = view.findViewById(R.id.tv_pantry_summary);
        btnFindRecipesLink = view.findViewById(R.id.btn_find_recipes_link);
        etSearch = view.findViewById(R.id.et_search_pantry);
        fabAdd = view.findViewById(R.id.fab_add_ingredient);

        chipAll = view.findViewById(R.id.chip_all);
        chipProduce = view.findViewById(R.id.chip_produce);
        chipDairy = view.findViewById(R.id.chip_dairy);
        chipMeat = view.findViewById(R.id.chip_meat);
        chipPantry = view.findViewById(R.id.chip_pantry);
        chipSpices = view.findViewById(R.id.chip_spices);

        setupChips();

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new PantryAdapter(requireContext(), pantryList, this);
        recyclerView.setAdapter(adapter);

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddEditIngredientActivity.class);
            startActivity(intent);
        });

        btnFindRecipesLink.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).switchToTab(R.id.nav_suggestions);
            }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentSearchQuery = s.toString().trim();
                filterAndRender();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        loadPantryItems();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadPantryItems();
    }

    public void loadPantryItems() {
        if (dbHelper == null) return;
        pantryList.clear();
        pantryList.addAll(dbHelper.getAllPantryItems());
        filterAndRender();

        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).updateSuggestionsBadge();
        }
    }

    private void setupChips() {
        View.OnClickListener chipListener = v -> {
            int id = v.getId();
            if (id == R.id.chip_all) selectedCategory = "All";
            else if (id == R.id.chip_produce) selectedCategory = "Produce";
            else if (id == R.id.chip_dairy) selectedCategory = "Dairy & Eggs";
            else if (id == R.id.chip_meat) selectedCategory = "Meat & Seafood";
            else if (id == R.id.chip_pantry) selectedCategory = "Pantry & Grains";
            else if (id == R.id.chip_spices) selectedCategory = "Spices & Condiments";

            updateChipStyles();
            filterAndRender();
        };

        chipAll.setOnClickListener(chipListener);
        chipProduce.setOnClickListener(chipListener);
        chipDairy.setOnClickListener(chipListener);
        chipMeat.setOnClickListener(chipListener);
        chipPantry.setOnClickListener(chipListener);
        chipSpices.setOnClickListener(chipListener);
    }

    private void updateChipStyles() {
        setChipState(chipAll, "All".equalsIgnoreCase(selectedCategory));
        setChipState(chipProduce, "Produce".equalsIgnoreCase(selectedCategory));
        setChipState(chipDairy, "Dairy & Eggs".equalsIgnoreCase(selectedCategory));
        setChipState(chipMeat, "Meat & Seafood".equalsIgnoreCase(selectedCategory));
        setChipState(chipPantry, "Pantry & Grains".equalsIgnoreCase(selectedCategory));
        setChipState(chipSpices, "Spices & Condiments".equalsIgnoreCase(selectedCategory));
    }

    private void setChipState(TextView chip, boolean isSelected) {
        if (chip == null) return;
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_chip_selected);
            chip.setTextColor(getResources().getColor(R.color.white, null));
        } else {
            chip.setBackgroundResource(R.drawable.bg_chip_unselected);
            chip.setTextColor(getResources().getColor(R.color.chip_unselected_text, null));
        }
    }

    private void filterAndRender() {
        List<PantryItem> filtered = new ArrayList<>();
        for (PantryItem item : pantryList) {
            boolean matchesCategory = "All".equalsIgnoreCase(selectedCategory) ||
                    (item.getCategory() != null && item.getCategory().equalsIgnoreCase(selectedCategory));
            boolean matchesSearch = currentSearchQuery.isEmpty() ||
                    item.getName().toLowerCase().contains(currentSearchQuery.toLowerCase());

            if (matchesCategory && matchesSearch) {
                filtered.add(item);
            }
        }

        adapter.updateList(filtered);
        tvSummary.setText(String.format("%d items in your SQLite pantry", pantryList.size()));

        if (filtered.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onEditClick(PantryItem item) {
        Intent intent = new Intent(requireContext(), AddEditIngredientActivity.class);
        intent.putExtra(AddEditIngredientActivity.EXTRA_ITEM_ID, item.getId());
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(PantryItem item) {
        dbHelper.deletePantryItem(item.getId());
        Toast.makeText(requireContext(), "Removed " + item.getName(), Toast.LENGTH_SHORT).show();
        loadPantryItems();
    }

    @Override
    public void onQuantityChange(PantryItem item, double newQuantity) {
        if (newQuantity <= 0) {
            dbHelper.deletePantryItem(item.getId());
            Toast.makeText(requireContext(), "Removed " + item.getName(), Toast.LENGTH_SHORT).show();
        } else {
            item.setQuantity(newQuantity);
            dbHelper.updatePantryItem(item);
        }
        loadPantryItems();
    }
}
