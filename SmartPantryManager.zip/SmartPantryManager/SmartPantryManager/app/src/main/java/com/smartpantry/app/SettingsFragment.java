package com.smartpantry.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import com.smartpantry.app.database.DatabaseHelper;

public class SettingsFragment extends Fragment {

    private SwitchCompat switchExpiryAlerts;
    private TextView btnDays2, btnDays3, btnDays5, btnDays7;
    private LinearLayout boxMetric, boxImperial;
    private Button btnResetDatabase;
    private DatabaseHelper dbHelper;

    private int selectedDays = 3;
    private boolean isMetric = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_settings, container, false);

        dbHelper = new DatabaseHelper(requireContext());

        switchExpiryAlerts = view.findViewById(R.id.switch_expiry_alerts);
        btnDays2 = view.findViewById(R.id.btn_days_2);
        btnDays3 = view.findViewById(R.id.btn_days_3);
        btnDays5 = view.findViewById(R.id.btn_days_5);
        btnDays7 = view.findViewById(R.id.btn_days_7);
        boxMetric = view.findViewById(R.id.box_unit_metric);
        boxImperial = view.findViewById(R.id.box_unit_imperial);
        btnResetDatabase = view.findViewById(R.id.btn_reset_database);

        switchExpiryAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Toast.makeText(requireContext(), "Expiry badges " + (isChecked ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
        });

        setupThresholdButtons();
        setupUnitBoxes();

        btnResetDatabase.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Reset Database")
                    .setMessage("Re-seed initial 20 recipes and restore default pantry inventory?")
                    .setPositiveButton("Reset", (dialog, which) -> {
                        dbHelper.resetToInitialSeed();
                        Toast.makeText(requireContext(), "Database re-seeded successfully", Toast.LENGTH_SHORT).show();
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).updateSuggestionsBadge();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        return view;
    }

    private void setupThresholdButtons() {
        View.OnClickListener listener = v -> {
            int id = v.getId();
            if (id == R.id.btn_days_2) selectedDays = 2;
            else if (id == R.id.btn_days_3) selectedDays = 3;
            else if (id == R.id.btn_days_5) selectedDays = 5;
            else if (id == R.id.btn_days_7) selectedDays = 7;

            updateDaysUI();
        };

        btnDays2.setOnClickListener(listener);
        btnDays3.setOnClickListener(listener);
        btnDays5.setOnClickListener(listener);
        btnDays7.setOnClickListener(listener);
    }

    private void updateDaysUI() {
        setBoxState(btnDays2, selectedDays == 2);
        setBoxState(btnDays3, selectedDays == 3);
        setBoxState(btnDays5, selectedDays == 5);
        setBoxState(btnDays7, selectedDays == 7);
    }

    private void setBoxState(TextView tv, boolean isSelected) {
        if (tv == null) return;
        if (isSelected) {
            tv.setBackgroundResource(R.drawable.bg_setting_box_selected);
            tv.setTextColor(getResources().getColor(R.color.primary, null));
        } else {
            tv.setBackgroundResource(R.drawable.bg_setting_box_unselected);
            tv.setTextColor(getResources().getColor(R.color.text_dark, null));
        }
    }

    private void setupUnitBoxes() {
        boxMetric.setOnClickListener(v -> {
            isMetric = true;
            boxMetric.setBackgroundResource(R.drawable.bg_setting_box_selected);
            boxImperial.setBackgroundResource(R.drawable.bg_setting_box_unselected);
            Toast.makeText(requireContext(), "Measurement unit set to Metric", Toast.LENGTH_SHORT).show();
        });

        boxImperial.setOnClickListener(v -> {
            isMetric = false;
            boxMetric.setBackgroundResource(R.drawable.bg_setting_box_unselected);
            boxImperial.setBackgroundResource(R.drawable.bg_setting_box_selected);
            Toast.makeText(requireContext(), "Measurement unit set to Imperial", Toast.LENGTH_SHORT).show();
        });
    }
}
