package com.smartpantry.app.logic;

import com.smartpantry.app.models.PantryItem;
import com.smartpantry.app.models.Recipe;
import com.smartpantry.app.models.RecipeIngredient;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Strict Matching Algorithm (Section 2.3 of Mobile App Development 700 Brief).
 * 
 * Strict rule:
 * 1. A recipe is suggested IF AND ONLY IF every required ingredient is in the pantry in >= required quantity.
 * 2. If a recipe needs 5 ingredients and user has 4, it is strictly excluded.
 * 3. Handles real-world messiness: singular/plural stemming ("tomatoes" -> "tomato") and unit conversion.
 */
public class StrictMatcher {

    public static class EvaluationResult {
        private final boolean isStrictMatch;
        private final int totalRequired;
        private final int matchedCount;
        private final int missingCount;
        private final Set<String> matchedNames;

        public EvaluationResult(boolean isStrictMatch, int totalRequired, int matchedCount, int missingCount, Set<String> matchedNames) {
            this.isStrictMatch = isStrictMatch;
            this.totalRequired = totalRequired;
            this.matchedCount = matchedCount;
            this.missingCount = missingCount;
            this.matchedNames = matchedNames;
        }

        public boolean isStrictMatch() { return isStrictMatch; }
        public int getTotalRequired() { return totalRequired; }
        public int getMatchedCount() { return matchedCount; }
        public int getMissingCount() { return missingCount; }
        public boolean isIngredientAvailable(String name) {
            return matchedNames.contains(normalize(name));
        }
    }

    /**
     * Stemming & culinary normalization. Avoids naive exact-string match failures.
     */
    public static String normalize(String name) {
        if (name == null) return "";
        String clean = name.toLowerCase().trim();

        // Strip adjectives
        clean = clean.replaceAll("\\b(fresh|ripe|large|medium|small|diced|chopped|sliced|cooked|leftover|skinless|boneless)\\b", "");
        clean = clean.replaceAll("\\s+", " ").trim();

        // Common synonyms
        if (clean.equals("scallion") || clean.equals("scallions") || clean.equals("spring onion")) return "green onion";
        if (clean.equals("capsicum") || clean.equals("sweet pepper")) return "bell pepper";
        if (clean.equals("soya sauce")) return "soy sauce";
        if (clean.equals("spaghetti") || clean.equals("macaroni") || clean.equals("penne")) return "pasta";
        if (clean.equals("cheddar") || clean.equals("cheddar cheese") || clean.equals("mozzarella")) return "cheese";
        if (clean.equals("chicken breast") || clean.equals("chicken thighs")) return "chicken";

        // Plural stemming
        if (clean.endsWith("tomatoes")) return clean.substring(0, clean.length() - 2); // tomato
        if (clean.endsWith("potatoes")) return clean.substring(0, clean.length() - 2); // potato
        if (clean.endsWith("leaves")) return clean.substring(0, clean.length() - 3) + "f";
        if (clean.endsWith("s") && !clean.endsWith("ss") && clean.length() > 3) {
            return clean.substring(0, clean.length() - 1);
        }

        return clean;
    }

    /**
     * Unit conversion handling metric & imperial kitchen standards.
     */
    public static Double convertUnits(double val, String fromUnit, String toUnit) {
        if (fromUnit.equalsIgnoreCase(toUnit)) return val;

        // Mass (grams base)
        if (fromUnit.equalsIgnoreCase("kg") && toUnit.equalsIgnoreCase("g")) return val * 1000.0;
        if (fromUnit.equalsIgnoreCase("g") && toUnit.equalsIgnoreCase("kg")) return val / 1000.0;

        // Volume (ml base)
        if (fromUnit.equalsIgnoreCase("l") && toUnit.equalsIgnoreCase("ml")) return val * 1000.0;
        if (fromUnit.equalsIgnoreCase("ml") && toUnit.equalsIgnoreCase("l")) return val / 1000.0;
        if (fromUnit.equalsIgnoreCase("tbsp") && toUnit.equalsIgnoreCase("tsp")) return val * 3.0;
        if (fromUnit.equalsIgnoreCase("cup") && toUnit.equalsIgnoreCase("ml")) return val * 240.0;

        return null; // Not strictly convertible
    }

    /**
     * Evaluates whether a recipe satisfies the strict matching rule.
     */
    public static EvaluationResult evaluate(Recipe recipe, List<PantryItem> pantry) {
        List<RecipeIngredient> required = recipe.getIngredients();
        int total = required.size();
        int matched = 0;
        Set<String> matchedNames = new HashSet<>();

        for (RecipeIngredient req : required) {
            String normReq = normalize(req.getName());
            double availableQty = 0;

            for (PantryItem p : pantry) {
                String normP = normalize(p.getName());
                if (normP.equals(normReq) || normP.contains(normReq) || normReq.contains(normP)) {
                    Double converted = convertUnits(p.getQuantity(), p.getUnit(), req.getUnit());
                    if (converted != null) {
                        availableQty += converted;
                    } else {
                        // Discrete / Count unit compatibility
                        availableQty += p.getQuantity();
                    }
                }
            }

            if (availableQty >= req.getQuantity()) {
                matched++;
                matchedNames.add(normReq);
            }
        }

        int missing = total - matched;
        boolean isStrict = (total > 0 && missing == 0);

        return new EvaluationResult(isStrict, total, matched, missing, matchedNames);
    }
}
