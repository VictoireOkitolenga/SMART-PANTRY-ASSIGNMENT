package com.smartpantry.app.models;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class PantryItem implements Serializable {
    private String id;
    private String name;
    private String normalizedName;
    private double quantity;
    private String unit;
    private String category;
    private String expiryDate; // YYYY-MM-DD
    private String notes;

    public PantryItem(String id, String name, String normalizedName, double quantity, String unit, String category, String expiryDate, String notes) {
        this.id = id;
        this.name = name;
        this.normalizedName = normalizedName;
        this.quantity = quantity;
        this.unit = unit;
        this.category = category;
        this.expiryDate = expiryDate;
        this.notes = notes;
    }

    public PantryItem(String id, String name, String normalizedName, double quantity, String unit, String category, String expiryDate) {
        this(id, name, normalizedName, quantity, unit, category, expiryDate, "");
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getNormalizedName() { return normalizedName; }
    public double getQuantity() { return quantity; }
    public String getUnit() { return unit; }
    public String getCategory() { return category; }
    public String getExpiryDate() { return expiryDate; }
    public String getNotes() { return notes != null ? notes : ""; }

    public void setQuantity(double quantity) { this.quantity = quantity; }
    public void setNotes(String notes) { this.notes = notes; }

    /**
     * Calculates remaining days until expiration.
     */
    public long getDaysLeft() {
        if (expiryDate == null || expiryDate.isEmpty()) return 999;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Date exp = sdf.parse(expiryDate);
            Date now = new Date();
            if (exp == null) return 999;
            long diff = exp.getTime() - now.getTime();
            return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) + 1;
        } catch (ParseException e) {
            return 999;
        }
    }
}
